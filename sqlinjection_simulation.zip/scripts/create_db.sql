-- Create schema
CREATE SCHEMA `sqlinjection` ;