DELETE FROM `sqlinjection`.`payments`;

DELETE FROM `sqlinjection`.`orderlines`;

DELETE FROM `sqlinjection`.`orders`;

DELETE FROM `sqlinjection`.`members`;

DELETE FROM `sqlinjection`.`permissions`;

DELETE FROM `sqlinjection`.`products`;

DELETE FROM `sqlinjection`.`categories`;

DROP TABLE `sqlinjection`.`payments`;

DROP TABLE `sqlinjection`.`orderlines`;

DROP TABLE `sqlinjection`.`orders`;

DROP TABLE `sqlinjection`.`members`;

DROP TABLE `sqlinjection`.`permissions`;

DROP TABLE `sqlinjection`.`products`;

DROP TABLE `sqlinjection`.`categories`;

DROP SCHEMA `sqlinjection` ;